NiceSelect.bind(document.getElementById("genderselect"), {
  searchable: false,
  placeholder: 'Male'
});