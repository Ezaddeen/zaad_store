$(document).ready(function() {
  $('#attendtable').DataTable({
    searching: false,
    paging: false,
    info: false,
  });
});