const year = new Date();
const copyright = document.querySelector('#copyrightyear');

copyright.innerHTML = year.getFullYear();