function buyNow(productDetails) {
  console.log(productDetails);
}
